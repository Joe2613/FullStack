import React, { useState } from 'react';import './App.css';
const App = () => {
const [email, setEmail] = useState('');
const [password, setPassword] = useState('');const handleEmailChange = (e) => {

setEmail(e.target.value);
};

const handlePasswordChange = (e) => { setPassword(e.target.value);
};

const handleSubmit = (e) => { e.preventDefault();
console.log(`E-mail: ${email}, Password: ${password}`);

};
return (
<div className="container">
<form onSubmit={handleSubmit} className="form">
<h1>Login Form</h1>
<label htmlFor="email">E-mail:</label>
<input type="text"
id="email" value={email}
onChange={handleEmailChange} required
/>
<label htmlFor="password">Password:</label>
<input type="password" id="password" value={password}
onChange={handlePasswordChange}required
/>
<button type="submit">Submit</button>
</form>
</div>
);
};

export default App;